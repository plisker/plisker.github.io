import sys
import exifread

def get_exif(file):
    f = open(file, 'rb')
    tags = exifread.process_file(f)
    make = tags["Image Make"]
    model = tags["Image Model"]
    for tag in tags.keys():
        if tag == "JPEGThumbnail":
            continue
        print tag+":", tags[tag]
        print ""
    return tags

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Error! No image file specified!")
        print("Usage: %s <filename>" % sys.argv[0])
        sys.exit(1)

    file = sys.argv[1]
    tags = get_exif(file)
    print "File:", file