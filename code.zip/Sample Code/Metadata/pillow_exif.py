import sys
from PIL import Image
import PIL.ExifTags
from PIL.ExifTags import TAGS, GPSTAGS


def get_exif_data(image):
    """Returns a dictionary from the exif data of an PIL Image item. Also converts the GPS Tags"""
    exif_data = {}
    info = image._getexif()
    if info:
        for tag, value in info.items():
            decoded = TAGS.get(tag, tag)
            if decoded == "GPSInfo":
                gps_data = {}
                for gps_tag in value:
                    sub_decoded = GPSTAGS.get(gps_tag, gps_tag)
                    gps_data[sub_decoded] = value[gps_tag]

                exif_data[decoded] = gps_data
            else:
                exif_data[decoded] = value

    for key in exif_data:
    	if key == "UserComment":
    		continue
        print key+":", exif_data[key]
        print ""
    return exif_data

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Error! No image file specified!")
        print("Usage: %s <filename>" % sys.argv[0])
        sys.exit(1)

    file = sys.argv[1]
    image = Image.open(file)
    exif_data = get_exif_data(image)
    # make, model = get_make_and_model(file)
    print "File:", file